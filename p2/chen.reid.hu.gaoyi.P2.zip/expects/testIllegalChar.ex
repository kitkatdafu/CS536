legal
_very_legal
_123Legal
!
_legal
____legal____123
