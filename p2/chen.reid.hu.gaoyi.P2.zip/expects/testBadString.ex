abc
""
"&!88"
"use \n to denote a newline character"
"include a quote like this \" and a backslash like this \\"
"two strings on one line"
"yes, this is the other string"
this_is_an_id
"str"
this_is_an_id
"str"
